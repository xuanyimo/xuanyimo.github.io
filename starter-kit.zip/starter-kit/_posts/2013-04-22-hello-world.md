---
layout: post
title: "Hello World!"
description: "The first 'Hello world' post for Simple Texture theme."
categories: [uncategorized]
tags: [random, jekyll]
redirect_from:
  - /2013/04/22/
---
Hello World! This is the beginning of this theme.